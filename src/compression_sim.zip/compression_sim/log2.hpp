#ifndef LOG2_HPP
#define LOG2_HPP

#include <stdint.h>

uint16_t func_log2(uint64_t input);

#endif
