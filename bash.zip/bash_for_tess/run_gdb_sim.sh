#!/bin/bash

gdb ~/mbc_research/build/src/compression_sim/run_sim_v2.exe
