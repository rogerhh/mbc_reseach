#!/bin/bash

../build/tests/select_datapoints_test.exe
../build/tests/sunrise_sunset_test.exe
../build/tests/get_weather_data_test.exe
