#!/bin/bash

~/mbc_research/build/src/dump_data.exe ~/mbc_research/data/test_database.csv ~/mbc_research/data/test_sensor.db
