#!/bin/bash

#~/mbc_research/build/src/read_data_into_database.exe ~/mbc_research/build/test_info_table.txt
#~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table.txt
#~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table_2.txt
#~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table_3.txt
#~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table_4.txt
#~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table_5.txt
#~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table_6.txt
#~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table_7.txt
#~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table_8.txt
#~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table_9.txt
#~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table_10.txt
~/mbc_research/build/src/read_data_into_database.exe ~/Dropbox/UMICH/EE\ Research/data/info_table_11.txt
