#!/bin/bash

~/mbc_research/build/src/read_file.exe ~/Dropbox/UMICH/EE\ Research/data/4-18-2018/4-18-18_logger25.csv 04/10/18-00:00:00 04/17/18-00:00:50 0 0 Research/data/4-27-2018/4-27-18_logger25.csv 04/19/18-00:00:00 04/27/18-00:00:50 0 0
#./read_file.exe xx xx xx xx xx
#./read_file.exe ~/Dropbox/UMICH/EE\ Research/data/4-27-2018/4-27-18_logger25.csv 04/19/18-00:00:00 04/27/18-00:00:50 0 0
