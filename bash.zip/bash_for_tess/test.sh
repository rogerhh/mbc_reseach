#!/bin/bash

DATA_DIR=~/"Dropbox/UMICH/EE Research/"
echo "$DATA_DIR"

ls "$DATA_DIR"
